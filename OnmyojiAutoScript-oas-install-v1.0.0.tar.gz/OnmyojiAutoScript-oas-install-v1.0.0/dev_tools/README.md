### 这三个都是窗口的管理工具

塞进仓库并不是一个很好的选择，现已移出，已链接形式提供，请查阅文档[**模拟器支持**](https://runhey.github.io/OnmyojiAutoScript-website/docs/user-manual/emulator-support)

- Spyxx (微软自家的)
- ViewWizard2(简易版本)
- ViewWizard3