page_img.json 表示探索部分的

page_img_2.json 表示 town部分的町中部分

page_img_3.json 表示庭院部分的

