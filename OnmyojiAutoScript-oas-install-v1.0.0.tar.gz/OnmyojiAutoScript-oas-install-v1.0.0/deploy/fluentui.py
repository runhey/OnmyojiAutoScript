# This Python file uses the following encoding: utf-8
# @author runhey
# github https://github.com/runhey

from deploy.config import DeployConfig
from deploy.logger import logger
from deploy.utils import *


class FluentuiManager(DeployConfig):
        pass