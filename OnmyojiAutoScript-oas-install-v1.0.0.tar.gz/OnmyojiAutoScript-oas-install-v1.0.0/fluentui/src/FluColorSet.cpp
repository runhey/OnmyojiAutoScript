#include "FluColorSet.h"

FluColorSet::FluColorSet(QObject *parent)
    : QObject{parent}
{

}
