﻿#ifndef EN_H
#define EN_H

#include <QObject>
#include "Lang.h"

class En : public Lang
{
    Q_OBJECT
public:
    explicit En(QObject *parent = nullptr);

signals:

};

#endif // EN_H
