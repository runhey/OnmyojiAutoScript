#include "Lang.h"

Lang::Lang(QObject *parent)
    : QObject{parent}
{

}
