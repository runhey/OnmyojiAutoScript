# This Python file uses the following encoding: utf-8
# @author runhey
# github https://github.com/runhey


from module.atom.ocr import RuleOcr
from module.atom.image import RuleImage
from module.logger import logger


class RuleScroll:
    pass


