这个是qt的翻译系统

[TS file format | Qt Linguist Manual](https://doc.qt.io/qt-6/linguist-ts-file-format.html)



你需要手动的编写ts文件并用linguist编译生成对应的qm文件

可以手动的用记事本打开ts文件.

context就是对应的qml所使用的翻译的文件名





![image-20230528155846492](https://runhey-img-stg1.oss-cn-chengdu.aliyuncs.com/img2/202305281558027.png)