<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>ItemsOriginal</name>
    <message>
        <source>home</source>
        <translation>home</translation>
    </message>
</context>
<context>
    <name>ItemsFooter</name>
    <message>
        <source>add</source>
        <translation>add</translation>
    </message>
    <message>
        <source>about</source>
        <translation>about</translation>
    </message>
    <message>
        <source>settings</source>
        <translation>settings</translation>
    </message>
</context>
<context>
    <name>O_Settings</name>
    <message>
        <source>Dark Mode</source>
        <translation>Dark Mode</translation>
    </message>
    <message>
        <source>System</source>
        <translation>System</translation>
    </message>
    <message>
        <source>Light</source>
        <translation>Light</translation>
    </message>
    <message>
        <source>Dark</source>
        <translation>Dark</translation>
    </message>
    <message>
        <source>navigation_view_display_mode</source>
        <translation>Navigation view display mode</translation>
    </message>
    <message>
        <source>Open</source>
        <translation>Open</translation>
    </message>
    <message>
        <source>Compact</source>
        <translation>Compact</translation>
    </message>
    <message>
        <source>Minimal</source>
        <translation>Minimal</translation>
    </message>
    <message>
        <source>Auto</source>
        <translation>Auto</translation>
    </message>
    <message>
        <source>Theme color</source>
        <translation>Theme color</translation>
    </message>
    <message>
        <source>Native text rendering</source>
        <translation>Native text rendering</translation>
    </message>
    <message>
        <source>Locale</source>
        <translation>Locale</translation>
    </message>
</context>
</TS>
