# This Python file uses the following encoding: utf-8
# @author runhey
# github https://github.com/runhey

from PySide6.QtCore import Qt, QObject

class Bridge(QObject):
    def __init__(self):
        super().__init__()





bridge = Bridge()